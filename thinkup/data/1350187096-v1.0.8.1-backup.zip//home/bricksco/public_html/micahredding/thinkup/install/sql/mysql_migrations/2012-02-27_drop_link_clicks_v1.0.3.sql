-- Moved this field to links_short in previous migration
ALTER TABLE tu_links DROP clicks;