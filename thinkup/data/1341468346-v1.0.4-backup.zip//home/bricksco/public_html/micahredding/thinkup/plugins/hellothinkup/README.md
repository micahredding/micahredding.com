Hello ThinkUp Plugin
======================

An example plugin for ThinkUp that servers as an example template for plugin developers.