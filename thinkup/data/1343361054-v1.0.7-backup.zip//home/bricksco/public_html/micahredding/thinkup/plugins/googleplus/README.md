Google Plus Plugin
==================

The Google Plus ThinkUp plugin retrieves posts for Google Plus users.
